"""
Roblox account linking.

Verification flow (no Roblox OAuth app required — uses Roblox's public,
unauthenticated read APIs):
  1. /link roblox_username   -> bot generates a short code, user pastes it
                                  into their Roblox profile "About" section
  2. /verify                 -> bot re-fetches the profile, checks the code
                                  is present, and stores the link
  3. /unlink                 -> removes the stored link
  4. /roblox [member]        -> shows a linked account's info

This only needs outbound HTTP (already available via aiohttp, already a
bot dependency) — no extra secrets/config required.
"""

from __future__ import annotations

import random
import string
import time

import aiohttp
import discord
from discord.ext import commands
from typing import Optional

import data_store

USERNAME_LOOKUP_URL = "https://users.roblox.com/v1/usernames/users"
USER_INFO_URL       = "https://users.roblox.com/v1/users/{user_id}"
THUMBNAIL_URL        = "https://thumbnails.roblox.com/v1/users/avatar-headshot"

PENDING_TTL_SECONDS = 15 * 60  # verification codes expire after 15 minutes


def _gen_code() -> str:
    return "botdi-" + "".join(random.choices(string.ascii_lowercase + string.digits, k=6))


class RobloxLink(commands.Cog):
    """Link a Discord account to a Roblox account."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        # discord_id -> {"roblox_id": int, "roblox_username": str, "code": str, "expires": float}
        self._pending: dict[int, dict] = {}

    async def _session(self) -> aiohttp.ClientSession:
        return aiohttp.ClientSession()

    async def _lookup_username(self, username: str) -> Optional[dict]:
        """Resolve a Roblox username to {'id': int, 'name': str} or None if not found."""
        async with await self._session() as s:
            async with s.post(
                USERNAME_LOOKUP_URL,
                json={"usernames": [username], "excludeBannedUsers": True},
                timeout=aiohttp.ClientTimeout(total=10),
            ) as resp:
                if resp.status != 200:
                    return None
                data = await resp.json()
                results = data.get("data", [])
                if not results:
                    return None
                return {"id": results[0]["id"], "name": results[0]["name"]}

    async def _get_description(self, roblox_id: int) -> Optional[str]:
        async with await self._session() as s:
            async with s.get(
                USER_INFO_URL.format(user_id=roblox_id),
                timeout=aiohttp.ClientTimeout(total=10),
            ) as resp:
                if resp.status != 200:
                    return None
                data = await resp.json()
                return data.get("description", "") or ""

    async def _get_avatar_url(self, roblox_id: int) -> Optional[str]:
        async with await self._session() as s:
            async with s.get(
                THUMBNAIL_URL,
                params={"userIds": str(roblox_id), "size": "150x150", "format": "Png"},
                timeout=aiohttp.ClientTimeout(total=10),
            ) as resp:
                if resp.status != 200:
                    return None
                data = await resp.json()
                items = data.get("data", [])
                if items and items[0].get("state") == "Completed":
                    return items[0].get("imageUrl")
                return None

    # ── Commands ─────────────────────────────────────────────────────────────

    @commands.hybrid_command(name="link")
    async def link_cmd(self, ctx: commands.Context, roblox_username: str) -> None:
        """Start linking your Roblox account to your Discord account."""
        await ctx.defer()

        existing = await data_store.get_roblox_link(ctx.author.id)
        if existing:
            await ctx.send(
                f"You're already linked to **{existing['roblox_username']}**. "
                f"Use `/unlink` first if you want to link a different account."
            )
            return

        info = await self._lookup_username(roblox_username)
        if info is None:
            await ctx.send(f"Couldn't find a Roblox user named **{roblox_username}**.")
            return

        already = await data_store.find_discord_by_roblox(info["id"])
        if already is not None:
            await ctx.send("That Roblox account is already linked to a different Discord account.")
            return

        code = _gen_code()
        self._pending[ctx.author.id] = {
            "roblox_id": info["id"],
            "roblox_username": info["name"],
            "code": code,
            "expires": time.time() + PENDING_TTL_SECONDS,
        }

        embed = discord.Embed(
            title="Verify your Roblox account",
            description=(
                f"1. Go to your [Roblox profile](https://www.roblox.com/users/{info['id']}/profile) "
                f"and edit your **About** section.\n"
                f"2. Paste this code anywhere in it:\n```\n{code}\n```\n"
                f"3. Come back and run `/verify`.\n\n"
                f"You can remove the code from your profile afterwards. Expires in 15 minutes."
            ),
            color=discord.Color.blue(),
        )
        await ctx.send(embed=embed)

    @commands.hybrid_command(name="verify")
    async def verify_cmd(self, ctx: commands.Context) -> None:
        """Finish linking your Roblox account after adding the code to your profile."""
        await ctx.defer()

        pending = self._pending.get(ctx.author.id)
        if pending is None:
            await ctx.send("No pending verification found. Run `/link <roblox_username>` first.")
            return

        if time.time() > pending["expires"]:
            self._pending.pop(ctx.author.id, None)
            await ctx.send("That verification code expired. Run `/link` again to get a new one.")
            return

        description = await self._get_description(pending["roblox_id"])
        if description is None:
            await ctx.send("Couldn't reach Roblox right now — try again in a moment.")
            return

        if pending["code"] not in description:
            await ctx.send(
                "Didn't find the code in your profile's About section yet. "
                "Make sure you saved it, then run `/verify` again "
                "(Roblox can take a minute to reflect the change)."
            )
            return

        await data_store.set_roblox_link(
            ctx.author.id, pending["roblox_id"], pending["roblox_username"]
        )
        self._pending.pop(ctx.author.id, None)

        embed = discord.Embed(
            title="Linked!",
            description=f"Your Discord account is now linked to **{pending['roblox_username']}**.",
            color=discord.Color.green(),
        )
        avatar_url = await self._get_avatar_url(pending["roblox_id"])
        if avatar_url:
            embed.set_thumbnail(url=avatar_url)
        await ctx.send(embed=embed)

    @commands.hybrid_command(name="unlink")
    async def unlink_cmd(self, ctx: commands.Context) -> None:
        """Remove your linked Roblox account."""
        removed = await data_store.remove_roblox_link(ctx.author.id)
        self._pending.pop(ctx.author.id, None)
        if removed:
            await ctx.send("Your Roblox account has been unlinked.")
        else:
            await ctx.send("You don't have a Roblox account linked.")

    @commands.hybrid_command(name="roblox")
    async def roblox_cmd(self, ctx: commands.Context, member: Optional[discord.Member] = None) -> None:
        """Show a member's linked Roblox account."""
        target = member or ctx.author
        link = await data_store.get_roblox_link(target.id)
        if link is None:
            who = "You don't" if target == ctx.author else f"{target.display_name} doesn't"
            await ctx.send(f"{who} have a Roblox account linked.")
            return

        await ctx.defer()
        embed = discord.Embed(
            title=link["roblox_username"],
            url=f"https://www.roblox.com/users/{link['roblox_id']}/profile",
            description=f"Linked Roblox account for {target.mention}",
            color=discord.Color.blue(),
        )
        avatar_url = await self._get_avatar_url(link["roblox_id"])
        if avatar_url:
            embed.set_thumbnail(url=avatar_url)
        await ctx.send(embed=embed)


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(RobloxLink(bot))
